import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { setSessionId } from '@workspace/api-client-react';
import Home from './pages/Home';

// Generate a persistent per-browser session ID
function getOrCreateSessionId(): string {
  const key = 'pdf417_session_id';
  let id = localStorage.getItem(key);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(key, id);
  }
  return id;
}

export const SESSION_ID = getOrCreateSessionId();
setSessionId(SESSION_ID);

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 min — SSE pushes updates, no need to poll
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      retry: 1,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route component={() => (
        <div className="min-h-[100dvh] flex flex-col items-center justify-center bg-background text-foreground font-mono font-black text-2xl uppercase">
           404 - SECTOR NOT FOUND
        </div>
      )} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL?.replace(/\/$/, '') || ''}>
        <Router />
      </WouterRouter>
      <Toaster 
        theme="system" 
        position="bottom-right" 
        toastOptions={{
          className: "font-mono uppercase font-bold border-2 border-primary rounded-none shadow-[4px_4px_0px_0px_var(--color-primary)]"
        }}
      />
    </QueryClientProvider>
  );
}

export default App;
