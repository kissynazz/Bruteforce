import path from "path";
import { EventEmitter } from "events";
import { spawn, ChildProcess } from "child_process";
import { logger } from "./logger";

export interface SearchStatus {
  running: boolean;
  target: string;
  attempts: number;
  rate: number;
  decodeRate: number;
  elapsed: number;
  foundCount: number;
}

export interface SearchMatch {
  id: string;
  text: string;
  format: string;
  imagePath: string;
  attempt: number;
  timestamp: string;
}

const PROJECT_ROOT = path.resolve(__dirname, "../../../");

// ── Per-session search manager ────────────────────────────────────────────────

export class SessionSearch extends EventEmitter {
  readonly sessionId: string;
  private proc: ChildProcess | null = null;
  private idleTimer: ReturnType<typeof setTimeout> | null = null;
  private readonly outDir: string;

  status: SearchStatus;
  matches: SearchMatch[] = [];

  constructor(sessionId: string) {
    super();
    this.sessionId = sessionId;
    this.outDir = path.join(PROJECT_ROOT, "found", sessionId);
    this.status = {
      running: false,
      target: "NAZZARA",
      attempts: 0,
      rate: 0,
      decodeRate: 0,
      elapsed: 0,
      foundCount: 0,
    };
    this.resetIdleTimer();
  }

  // Keep session alive while SSE is connected
  touch(): void {
    this.resetIdleTimer();
  }

  private resetIdleTimer(): void {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    // Destroy session after 15 min of no SSE connection
    this.idleTimer = setTimeout(() => {
      this.stop();
      this.emit("destroy");
    }, 15 * 60 * 1000);
  }

  getStatus(): SearchStatus { return { ...this.status }; }
  getMatches(): SearchMatch[] { return [...this.matches]; }

  start(target?: string): SearchStatus {
    if (this.proc) return this.getStatus();
    if (target?.trim()) this.status.target = target.trim().toUpperCase();

    this.status = { ...this.status, running: true, attempts: 0, rate: 0, decodeRate: 0, elapsed: 0 };

    const vendorPython = path.join(PROJECT_ROOT, "vendor", "python");
    const existing = process.env.PYTHONPATH ?? "";
    const pythonPath = existing ? `${vendorPython}:${existing}` : vendorPython;

    const args = [
      path.join(PROJECT_ROOT, "pdf417_search.py"),
      "--json-output",
      "--target", this.status.target,
      "--outdir", this.outDir,
    ];

    this.proc = spawn("python3", args, {
      cwd: PROJECT_ROOT,
      env: { ...process.env, PYTHONPATH: pythonPath },
    });

    let buf = "";
    this.proc.stdout?.on("data", (chunk: Buffer) => {
      buf += chunk.toString();
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        const t = line.trim();
        if (!t.startsWith("{")) continue;
        try { this.handleEvent(JSON.parse(t)); } catch { /* not JSON */ }
      }
    });

    this.proc.stderr?.on("data", (chunk: Buffer) => {
      const msg = chunk.toString().trim();
      if (msg) logger.warn({ session: this.sessionId, stderr: msg }, "search stderr");
    });

    this.proc.on("exit", (code) => {
      logger.info({ session: this.sessionId, code }, "Search process exited");
      this.status.running = false;
      this.proc = null;
      this.emit("status", this.getStatus());
    });

    logger.info({ session: this.sessionId, target: this.status.target }, "Search started");
    this.emit("status", this.getStatus());
    return this.getStatus();
  }

  stop(): SearchStatus {
    if (this.proc) { this.proc.kill("SIGTERM"); this.proc = null; }
    this.status.running = false;
    this.emit("status", this.getStatus());
    return this.getStatus();
  }

  destroy(): void {
    if (this.idleTimer) clearTimeout(this.idleTimer);
    this.stop();
  }

  private handleEvent(event: Record<string, unknown>): void {
    if (event.type === "stats") {
      this.status = {
        ...this.status,
        attempts: (event.attempts as number) ?? this.status.attempts,
        rate: (event.rate as number) ?? this.status.rate,
        decodeRate: (event.decodeRate as number) ?? this.status.decodeRate,
        elapsed: (event.elapsed as number) ?? this.status.elapsed,
      };
      this.emit("status", this.getStatus());
    } else if (event.type === "found") {
      const match: SearchMatch = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        text: String(event.text ?? ""),
        format: String(event.format ?? "PDF417"),
        imagePath: String(event.path ?? ""),
        attempt: (event.attempt as number) ?? 0,
        timestamp: new Date().toISOString(),
      };
      this.matches.push(match);
      this.status.foundCount = this.matches.length;
      logger.info({ session: this.sessionId, text: match.text }, "Match found");
      this.emit("match", match);
      this.emit("status", this.getStatus());
      this.sendEmail(match);
    }
  }

  private sendEmail(match: SearchMatch): void {
    const imgPath = path.isAbsolute(match.imagePath)
      ? match.imagePath
      : path.join(PROJECT_ROOT, match.imagePath);
    const emailScript = path.join(PROJECT_ROOT, "send_match_email.py");
    const proc = spawn("python3", [emailScript, imgPath, match.text], {
      cwd: PROJECT_ROOT,
      env: { ...process.env },
    });
    proc.stdout?.on("data", (d: Buffer) => logger.info({ msg: d.toString().trim() }, "email"));
    proc.stderr?.on("data", (d: Buffer) => logger.warn({ msg: d.toString().trim() }, "email error"));
  }
}

// ── Session store ─────────────────────────────────────────────────────────────

const sessions = new Map<string, SessionSearch>();

export function getOrCreateSession(sessionId: string): SessionSearch {
  let session = sessions.get(sessionId);
  if (!session) {
    session = new SessionSearch(sessionId);
    session.once("destroy", () => {
      sessions.delete(sessionId);
      logger.info({ session: sessionId }, "Session destroyed");
    });
    sessions.set(sessionId, session);
    logger.info({ session: sessionId }, "Session created");
  }
  return session;
}

export function getSession(sessionId: string): SessionSearch | undefined {
  return sessions.get(sessionId);
}
