import { Router, type Request, type Response } from "express";
import path from "path";
import fs from "fs";
import { getOrCreateSession, type SessionSearch } from "../lib/sessionStore";

const searchRouter = Router();

const PROJECT_ROOT = path.resolve(__dirname, "../../../");

// ── Helper: extract session ID from request ───────────────────────────────────

function sessionId(req: Request): string {
  // Headers for normal fetch calls; query param for EventSource (can't set headers)
  const fromHeader = req.headers["x-session-id"];
  const fromQuery = req.query["session"];
  const id = (Array.isArray(fromHeader) ? fromHeader[0] : fromHeader)
    ?? (Array.isArray(fromQuery) ? fromQuery[0] : fromQuery);
  return (id as string | undefined) || "default";
}

// ── Control endpoints ──────────────────────────────────────────────────────────

searchRouter.post("/search/start", async (req: Request, res: Response): Promise<void> => {
  const { target } = (req.body ?? {}) as { target?: string };
  const session = getOrCreateSession(sessionId(req));
  session.touch();
  res.json(session.start(target));
});

searchRouter.post("/search/stop", async (req: Request, res: Response): Promise<void> => {
  const session = getOrCreateSession(sessionId(req));
  session.touch();
  res.json(session.stop());
});

searchRouter.get("/search/status", async (req: Request, res: Response): Promise<void> => {
  const session = getOrCreateSession(sessionId(req));
  session.touch();
  res.json(session.getStatus());
});

searchRouter.get("/search/matches", async (req: Request, res: Response): Promise<void> => {
  const session = getOrCreateSession(sessionId(req));
  session.touch();
  res.json({ matches: session.getMatches() });
});

// ── SSE stream ────────────────────────────────────────────────────────────────

searchRouter.get("/search/stream", (req: Request, res: Response): void => {
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const session: SessionSearch = getOrCreateSession(sessionId(req));
  session.touch();

  // Send current state immediately
  res.write(`data: ${JSON.stringify({ type: "status", ...session.getStatus() })}\n\n`);
  for (const match of session.getMatches()) {
    res.write(`data: ${JSON.stringify({ type: "match", match })}\n\n`);
  }

  const onStatus = (status: object) =>
    res.write(`data: ${JSON.stringify({ type: "status", ...status })}\n\n`);
  const onMatch = (match: object) =>
    res.write(`data: ${JSON.stringify({ type: "match", match })}\n\n`);

  session.on("status", onStatus);
  session.on("match", onMatch);

  // Heartbeat every 20 s
  const hb = setInterval(() => {
    try { res.write(": heartbeat\n\n"); session.touch(); } catch { clearInterval(hb); }
  }, 20_000);

  req.on("close", () => {
    clearInterval(hb);
    session.removeListener("status", onStatus);
    session.removeListener("match", onMatch);
  });
});

// ── Serve found barcode images ────────────────────────────────────────────────

searchRouter.get("/found/:session/:filename", (req: Request, res: Response): void => {
  const sid = path.basename(req.params.session);
  const filename = path.basename(req.params.filename);
  const filepath = path.join(PROJECT_ROOT, "found", sid, filename);
  if (!fs.existsSync(filepath)) { res.status(404).json({ error: "Not found" }); return; }
  res.sendFile(filepath);
});

// Legacy single-level route for backward compat
searchRouter.get("/found/:filename", (req: Request, res: Response): void => {
  const filename = path.basename(req.params.filename);
  const filepath = path.join(PROJECT_ROOT, "found", filename);
  if (!fs.existsSync(filepath)) { res.status(404).json({ error: "Not found" }); return; }
  res.sendFile(filepath);
});

export default searchRouter;
