import { useState, useEffect, useRef } from 'react';
import {
  useStartSearch,
  useStopSearch,
  useGetSearchMatches,
  useGetSearchStatus,
  getGetSearchMatchesQueryKey
} from '@workspace/api-client-react';
import { SESSION_ID } from '../App';
import { useQueryClient } from '@tanstack/react-query';
import { Play, Square, Crosshair, Activity, Cpu, Clock, Hash, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

const formatElapsed = (sec: number) => {
  const h = Math.floor(sec / 3600).toString().padStart(2, '0');
  const m = Math.floor((sec % 3600) / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${h}:${m}:${s}`;
};

function StatBox({ icon, label, value, highlight = false }: { icon: React.ReactNode, label: string, value: string | number, highlight?: boolean }) {
  return (
    <div className={`border-4 border-primary p-4 md:p-6 flex flex-col gap-2 relative overflow-hidden group shadow-[4px_4px_0px_0px_var(--color-primary)] transition-colors ${highlight ? 'bg-primary text-primary-foreground' : 'bg-card'}`}>
      <div className={`flex items-center gap-2 text-xs md:text-sm font-black uppercase tracking-widest ${highlight ? 'text-primary-foreground/80' : 'text-muted-foreground'}`}>
        {icon} {label}
      </div>
      <div className="text-3xl md:text-4xl lg:text-5xl font-black truncate">{value}</div>
      {/* Decorative lines */}
      <div className={`absolute top-0 right-0 w-12 h-12 -rotate-45 translate-x-6 -translate-y-6 transition-transform duration-500 group-hover:scale-150 ${highlight ? 'bg-primary-foreground/10' : 'bg-primary/5'}`} />
    </div>
  );
}

function MatchCard({ match }: { match: any }) {
  const filename = match.imagePath.split('/').pop() || match.imagePath;
  const imageUrl = `/api/found/${SESSION_ID}/${filename}`;

  return (
    <div className="border-4 border-primary bg-card flex flex-col overflow-hidden shadow-[6px_6px_0px_0px_var(--color-primary)] hover:translate-y-[-2px] hover:translate-x-[-2px] hover:shadow-[8px_8px_0px_0px_var(--color-primary)] transition-all">
      <div className="p-3 border-b-4 border-primary bg-primary text-primary-foreground flex justify-between items-center text-xs md:text-sm font-black tracking-widest">
        <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4" /> SECURED</span>
        <span>{new Date(match.timestamp).toLocaleTimeString()}</span>
      </div>
      <div className="p-6 flex-1 flex flex-col items-center justify-center bg-secondary/30 relative min-h-[220px]">
         {/* Crosshairs decor */}
         <div className="absolute top-4 left-4 w-4 h-4 border-t-4 border-l-4 border-primary/20" />
         <div className="absolute top-4 right-4 w-4 h-4 border-t-4 border-r-4 border-primary/20" />
         <div className="absolute bottom-4 left-4 w-4 h-4 border-b-4 border-l-4 border-primary/20" />
         <div className="absolute bottom-4 right-4 w-4 h-4 border-b-4 border-r-4 border-primary/20" />

         <img src={imageUrl} alt={`Barcode for ${match.text}`} className="max-w-full h-auto object-contain max-h-48 drop-shadow-md" />
      </div>
      <div className="p-4 border-t-4 border-primary bg-secondary/50 text-sm flex flex-col gap-2 font-mono">
        <div className="flex justify-between border-b-2 border-primary/10 pb-2">
          <span className="text-muted-foreground font-black">ID</span>
          <span className="font-bold truncate max-w-[150px]">{match.id}</span>
        </div>
        <div className="flex justify-between border-b-2 border-primary/10 pb-2">
          <span className="text-muted-foreground font-black">TARGET</span>
          <span className="font-black text-primary text-base">{match.text}</span>
        </div>
        <div className="flex justify-between pt-1">
          <span className="text-muted-foreground font-black">ATTEMPT #</span>
          <span className="font-bold">{match.attempt.toLocaleString()}</span>
        </div>
      </div>
    </div>
  );
}

export default function Home() {
  const queryClient = useQueryClient();
  const startSearch = useStartSearch();
  const stopSearch = useStopSearch();
  const { data: matchesData } = useGetSearchMatches();
  const { data: initialStatus } = useGetSearchStatus();

  const [target, setTarget] = useState('REPLIT');
  const [status, setStatus] = useState({
    running: false, attempts: 0, rate: 0, decodeRate: 0, elapsed: 0, foundCount: 0
  });

  const initializedForId = useRef(false);

  useEffect(() => {
    if (initialStatus && !initializedForId.current) {
      setStatus(initialStatus);
      if (initialStatus.target) setTarget(initialStatus.target);
      initializedForId.current = true;
    }
  }, [initialStatus]);

  useEffect(() => {
    let es: EventSource | null = null;
    let retryTimeout: ReturnType<typeof setTimeout> | null = null;
    let retryDelay = 3000;
    let destroyed = false;

    function connect() {
      if (destroyed) return;
      es = new EventSource(`/api/search/stream?session=${SESSION_ID}`);
      es.onopen = () => { retryDelay = 3000; }; // reset backoff on success
      es.onmessage = (e) => {
        try {
          const data = JSON.parse(e.data);
          if (data.type === 'status') {
            setStatus({
              running: data.running,
              attempts: data.attempts,
              rate: data.rate,
              decodeRate: data.decodeRate,
              elapsed: data.elapsed,
              foundCount: data.foundCount,
            });
            if (data.running && data.target) setTarget(data.target);
          } else if (data.type === 'match') {
            queryClient.invalidateQueries({ queryKey: getGetSearchMatchesQueryKey() });
            toast.success(`TARGET ACQUIRED: ${data.match.text}`);
          }
        } catch (err) {
          console.error("Failed to parse SSE", err);
        }
      };
      es.onerror = () => {
        es?.close();
        es = null;
        if (!destroyed) {
          retryTimeout = setTimeout(() => {
            retryDelay = Math.min(retryDelay * 2, 30000); // cap at 30s
            connect();
          }, retryDelay);
        }
      };
    }

    connect();
    return () => {
      destroyed = true;
      if (retryTimeout) clearTimeout(retryTimeout);
      es?.close();
    };
  }, [queryClient]);

  const handleToggle = () => {
    if (status.running) {
      stopSearch.mutate(undefined, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetSearchMatchesQueryKey() }),
        onError: () => toast.error("Failed to abort search")
      });
    } else {
      if (!target.trim()) {
        toast.error("Target string required");
        return;
      }
      startSearch.mutate({ data: { target } }, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: getGetSearchMatchesQueryKey() }),
        onError: () => toast.error("Failed to engage search")
      });
    }
  };

  const matches = matchesData?.matches || [];

  return (
    <div className="min-h-[100dvh] bg-background text-foreground font-mono p-4 md:p-8 relative selection:bg-primary selection:text-primary-foreground">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Header & Control Panel */}
        <header className="flex flex-col xl:flex-row items-start xl:items-end justify-between gap-8 border-b-8 border-primary pb-8">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-primary text-primary-foreground text-xs font-black tracking-widest mb-2 shadow-[2px_2px_0px_0px_var(--color-secondary-foreground)]">
              <div className={`w-2 h-2 rounded-full ${status.running ? 'bg-destructive animate-pulse' : 'bg-muted'}`} />
              SYS.V.1.0 // {status.running ? 'ACTIVE' : 'STANDBY'}
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-black uppercase tracking-tighter leading-none flex items-center gap-4">
              PDF417 <span className="text-muted-foreground/30">//</span> Hunter
            </h1>
            <p className="text-muted-foreground font-bold tracking-widest uppercase md:text-lg">
              Pixel-space brute-force decoding matrix
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-end gap-4 w-full xl:w-auto mt-4 xl:mt-0">
            <div className="flex flex-col flex-1 sm:flex-none">
              <label className="text-xs font-black uppercase tracking-widest text-primary mb-2 flex items-center gap-2">
                <Crosshair className="h-4 w-4" /> Target String
              </label>
              <input
                value={target}
                onChange={(e) => setTarget(e.target.value.toUpperCase())}
                disabled={status.running}
                placeholder="ENTER TARGET"
                className="bg-card border-4 border-primary px-4 py-3 md:py-4 text-2xl md:text-3xl font-black outline-none focus:border-primary/80 focus:bg-secondary/50 w-full sm:w-72 disabled:opacity-50 disabled:cursor-not-allowed shadow-[4px_4px_0px_0px_var(--color-primary)] placeholder:text-muted-foreground/30 transition-colors uppercase"
              />
            </div>
            <button
              onClick={handleToggle}
              disabled={startSearch.isPending || stopSearch.isPending}
              className={`group flex items-center justify-center h-[60px] md:h-[72px] px-8 md:px-12 text-2xl md:text-3xl font-black uppercase transition-all border-4 shadow-[4px_4px_0px_0px_var(--color-primary)] active:translate-y-[4px] active:translate-x-[4px] active:shadow-[0px_0px_0px_0px_var(--color-primary)] disabled:opacity-50 disabled:cursor-not-allowed ${
                status.running
                  ? 'bg-destructive text-destructive-foreground border-primary hover:bg-destructive/90 hover:shadow-[6px_6px_0px_0px_var(--color-primary)]'
                  : 'bg-primary text-primary-foreground border-primary hover:bg-primary/90 hover:shadow-[6px_6px_0px_0px_var(--color-primary)]'
              }`}
            >
              {status.running ? (
                <><Square className="mr-3 md:mr-4 h-6 w-6 md:h-8 md:w-8 fill-current animate-pulse" /> ABORT</>
              ) : (
                <><Play className="mr-3 md:mr-4 h-6 w-6 md:h-8 md:w-8 fill-current group-hover:scale-110 transition-transform" /> ENGAGE</>
              )}
            </button>
          </div>
        </header>

        {/* Live Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          <StatBox icon={<Hash/>} label="Total Attempts" value={status.attempts.toLocaleString()} highlight={status.running} />
          <StatBox icon={<Activity/>} label="Attempts / Sec" value={status.rate.toLocaleString()} />
          <StatBox icon={<Cpu/>} label="Decode Success %" value={`${status.decodeRate.toFixed(4)}%`} />
          <StatBox icon={<Clock/>} label="Elapsed Time" value={formatElapsed(status.elapsed)} />
        </div>

        {/* Matches Area */}
        <div className="space-y-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b-8 border-primary pb-6 gap-4">
            <h2 className="text-3xl md:text-4xl font-black uppercase flex items-center gap-4 tracking-tighter">
              <div className="p-2 md:p-3 bg-primary text-primary-foreground shadow-[4px_4px_0px_0px_var(--color-secondary-foreground)]">
                <Crosshair className="h-6 w-6 md:h-8 md:w-8" />
              </div>
              Confirmed Matches ({matches.length})
            </h2>
            {status.running && (
              <div className="flex items-center gap-3 text-sm md:text-base font-black tracking-widest text-primary px-6 py-3 border-4 border-primary bg-secondary/50 shadow-[4px_4px_0px_0px_var(--color-primary)]">
                <div className="h-3 w-3 bg-destructive animate-pulse" />
                SEARCHING PIXEL SPACE...
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {matches.map(match => (
              <MatchCard key={match.id} match={match} />
            ))}

            {matches.length === 0 && (
              <div className={`col-span-full py-32 md:py-48 text-center border-4 border-dashed border-primary/20 text-muted-foreground bg-secondary/20 flex flex-col items-center justify-center gap-6 ${status.running ? 'animate-pulse' : ''}`}>
                <Activity className="h-16 w-16 opacity-50" />
                <span className="text-xl md:text-2xl font-black tracking-widest uppercase">
                  {status.running ? 'ANALYZING NOISE PATTERNS...' : 'SYSTEM STANDBY. AWAITING TARGET ACQUISITION.'}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
