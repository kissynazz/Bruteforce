# Barcode scan results
# Source image : IMG_2445_1782471224951.png
# Scanned on   : 2026-06-26
# Scanner      : zxing-cpp 3.0.0

results = [
    {
        "format": "Code 128",
        "data": "0100323380017331",
        "source": "IMG_2445_1782471224951.png",
    },
]

# Summary
# -------
# Total barcodes found : 1
#
# [1] Code 128
#     Data   : 0100323380017331
#     Source : IMG_2445_1782471224951.png
#
# Note: A PDF417 barcode is visible on the license but could not be fully
# decoded from this image — the barcode region appears partially obscured
# or the image resolution in that area is insufficient for PDF417 decoding.
