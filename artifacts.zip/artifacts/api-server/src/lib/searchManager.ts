import { spawn, ChildProcess } from "child_process";
import { EventEmitter } from "events";
import path from "path";
import { logger } from "./logger";

export interface SearchStatus {
  running: boolean;
  target: string;
  attempts: number;
  rate: number;
  decodeRate: number;
  elapsed: number;
  foundCount: number;
}

export interface SearchMatch {
  id: string;
  text: string;
  format: string;
  imagePath: string;
  attempt: number;
  timestamp: string;
}

// Project root: artifacts/api-server/src/lib/ → go up 4 levels
const PROJECT_ROOT = path.resolve(__dirname, "../../../");

class SearchManager extends EventEmitter {
  private proc: ChildProcess | null = null;
  private status: SearchStatus = {
    running: false,
    target: "NAZZARA",
    attempts: 0,
    rate: 0,
    decodeRate: 0,
    elapsed: 0,
    foundCount: 0,
  };
  private matches: SearchMatch[] = [];

  getStatus(): SearchStatus {
    return { ...this.status };
  }

  getMatches(): SearchMatch[] {
    return [...this.matches];
  }

  start(target?: string): SearchStatus {
    if (this.proc) {
      return this.getStatus();
    }

    if (target && target.trim()) {
      this.status.target = target.trim().toUpperCase();
    }

    this.status = {
      ...this.status,
      running: true,
      attempts: 0,
      rate: 0,
      decodeRate: 0,
      elapsed: 0,
    };

    const args = [
      path.join(PROJECT_ROOT, "pdf417_search.py"),
      "--json-output",
      "--target",
      this.status.target,
    ];

    const vendorPython = path.join(PROJECT_ROOT, "vendor", "python");
    const existingPythonPath = process.env.PYTHONPATH ?? "";
    const pythonPath = existingPythonPath
      ? `${vendorPython}:${existingPythonPath}`
      : vendorPython;

    this.proc = spawn("python3", args, {
      cwd: PROJECT_ROOT,
      env: { ...process.env, PYTHONPATH: pythonPath },
    });

    let buffer = "";
    this.proc.stdout?.on("data", (chunk: Buffer) => {
      buffer += chunk.toString();
      const lines = buffer.split("\n");
      buffer = lines.pop() ?? "";
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith("{")) continue;
        try {
          const event = JSON.parse(trimmed);
          this.handleEvent(event);
        } catch {
          // not JSON
        }
      }
    });

    this.proc.stderr?.on("data", (chunk: Buffer) => {
      const msg = chunk.toString().trim();
      if (msg) logger.warn({ stderr: msg }, "search stderr");
    });

    this.proc.on("exit", (code) => {
      logger.info({ code }, "Search process exited");
      this.status.running = false;
      this.proc = null;
      this.emit("status", this.getStatus());
    });

    logger.info({ target: this.status.target }, "Search started");
    this.emit("status", this.getStatus());
    return this.getStatus();
  }

  stop(): SearchStatus {
    if (this.proc) {
      this.proc.kill("SIGTERM");
      this.proc = null;
    }
    this.status.running = false;
    logger.info("Search stopped");
    this.emit("status", this.getStatus());
    return this.getStatus();
  }

  private handleEvent(event: Record<string, unknown>): void {
    if (event.type === "stats") {
      this.status = {
        ...this.status,
        attempts: (event.attempts as number) ?? this.status.attempts,
        rate: (event.rate as number) ?? this.status.rate,
        decodeRate: (event.decodeRate as number) ?? this.status.decodeRate,
        elapsed: (event.elapsed as number) ?? this.status.elapsed,
      };
      this.emit("status", this.getStatus());
    } else if (event.type === "found") {
      const match: SearchMatch = {
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        text: String(event.text ?? ""),
        format: String(event.format ?? "PDF417"),
        imagePath: String(event.path ?? ""),
        attempt: (event.attempt as number) ?? 0,
        timestamp: new Date().toISOString(),
      };
      this.matches.push(match);
      this.status.foundCount = this.matches.length;
      logger.info({ text: match.text, path: match.imagePath }, "Match found");
      this.emit("match", match);
      this.emit("status", this.getStatus());
      this.sendEmail(match);
    }
  }

  private sendEmail(match: SearchMatch): void {
    const imgPath = path.isAbsolute(match.imagePath)
      ? match.imagePath
      : path.join(PROJECT_ROOT, match.imagePath);

    const emailScript = path.join(PROJECT_ROOT, "send_match_email.py");
    const proc = spawn("python3", [emailScript, imgPath, match.text], {
      cwd: PROJECT_ROOT,
      env: { ...process.env },
    });

    proc.stdout?.on("data", (d: Buffer) =>
      logger.info({ msg: d.toString().trim() }, "email")
    );
    proc.stderr?.on("data", (d: Buffer) =>
      logger.warn({ msg: d.toString().trim() }, "email error")
    );
  }
}

export const searchManager = new SearchManager();
